create view v_pembelian_per_hari as
  select '1' AS `view`, cast(`t`.`waktu_transaksi` as date) AS `tgl`, sum(`v`.`biaya_pembelian`) AS `tot_pembelian`
  from (`id6664247_toko`.`v_trans_pembelian_total` `v` join `id6664247_toko`.`trans_pembelian` `t` on ((`v`.`id_trans` =
                                                                                                        `t`.`id_trans`)))
  group by 1
  order by 1 desc;

