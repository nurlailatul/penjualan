create view v_trans_penjualan_total as
  select `v`.`id_trans`                                                                           AS `id_trans`,
         `t`.`jenis_transaksi`                                                                    AS `jenis_transaksi`,
         `t`.`diskon`                                                                             AS `diskon`,
         `t`.`biaya_tambahan`                                                                     AS `biaya_tambahan`,
         `t`.`biaya_pembatalan`                                                                   AS `biaya_pembatalan`,
         `pg`.`biaya_pengiriman`                                                                  AS `biaya_pengiriman`,
         `v`.`tot_harga_beli`                                                                     AS `tot_harga_beli`,
         if((`t`.`jenis_transaksi` = 'DROPSHIP'), `v`.`tot_harga_reseller`, `v`.`tot_harga_umum`) AS `tot_harga_jual`
  from ((`id6664247_toko`.`v_trans_penjualan` `v` join `id6664247_toko`.`trans_penjualan` `t` on ((`v`.`id_trans` =
                                                                                                   `t`.`id_trans`))) left join `id6664247_toko`.`pengiriman_trans_penjualan` `pg` on ((
    `t`.`id_trans` = `pg`.`id_trans`)))
  where 1
  order by 1 desc;

