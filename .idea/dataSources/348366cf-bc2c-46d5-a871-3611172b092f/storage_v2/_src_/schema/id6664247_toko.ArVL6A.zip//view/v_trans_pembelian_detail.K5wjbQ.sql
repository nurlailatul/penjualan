create view v_trans_pembelian_detail as
  select `tp`.`id_trans`                              AS `id_trans`,
         `tpd`.`id_barang_history`                    AS `id_barang_history`,
         `bh`.`id_barang`                             AS `id_barang`,
         `tpd`.`jumlah_pax`                           AS `jumlah_pax`,
         `bh`.`harga_beli`                            AS `harga_beli`,
         (`tpd`.`jumlah_pax` * `bh`.`harga_beli`)     AS `tot_harga_beli`,
         `bh`.`harga_reseller`                        AS `harga_reseller`,
         (`tpd`.`jumlah_pax` * `bh`.`harga_reseller`) AS `tot_harga_reseller`,
         `bh`.`harga_umum`                            AS `harga_umum`,
         (`tpd`.`jumlah_pax` * `bh`.`harga_umum`)     AS `tot_harga_umum`
  from ((`id6664247_toko`.`trans_pembelian` `tp` join `id6664247_toko`.`trans_pembelian_detail` `tpd` on ((
    `tp`.`id_trans` = `tpd`.`id_trans`))) join `id6664247_toko`.`barang_history` `bh` on ((`tpd`.`id_barang_history` =
                                                                                           `bh`.`id_history`)))
  where 1
  order by `tp`.`id_trans` desc;

