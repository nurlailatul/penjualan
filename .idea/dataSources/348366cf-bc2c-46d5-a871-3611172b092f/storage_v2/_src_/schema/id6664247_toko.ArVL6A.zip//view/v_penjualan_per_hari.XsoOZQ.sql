create view v_penjualan_per_hari as
  select cast(`t`.`waktu_transaksi` as date) AS `tgl`,
         sum(`v`.`biaya_penjualan`)          AS `tot_penjualan`,
         sum(`v`.`laba`)                     AS `tot_laba`
  from (`id6664247_toko`.`v_trans_penjualan_total_all` `v` join `id6664247_toko`.`trans_penjualan` `t` on ((
    `v`.`id_trans` = `t`.`id_trans`)))
  group by 1
  order by 1 desc;

