create view v_pembelian_supplier_per_hari as
  select '1'                                 AS `view`,
         cast(`t`.`waktu_transaksi` as date) AS `tgl`,
         `t`.`id_supplier`                   AS `id_supplier`,
         sum(`v`.`biaya_pembelian`)          AS `tot_pembelian`
  from (`id6664247_toko`.`v_trans_pembelian_total` `v` join `id6664247_toko`.`trans_pembelian` `t` on ((`v`.`id_trans` =
                                                                                                        `t`.`id_trans`)))
  where (`t`.`id_supplier` is not null)
  group by 1, 2
  order by 1 desc;

