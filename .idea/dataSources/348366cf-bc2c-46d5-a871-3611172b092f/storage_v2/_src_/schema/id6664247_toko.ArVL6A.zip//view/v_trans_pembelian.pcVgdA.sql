create view v_trans_pembelian as
  select `v`.`id_trans`                AS `id_trans`,
         `t`.`biaya_tambahan`          AS `biaya_tambahan`,
         sum(`v`.`tot_harga_beli`)     AS `tot_harga_beli`,
         sum(`v`.`tot_harga_reseller`) AS `tot_harga_reseller`,
         sum(`v`.`tot_harga_umum`)     AS `tot_harga_umum`
  from (`id6664247_toko`.`v_trans_pembelian_detail` `v` join `id6664247_toko`.`trans_pembelian` `t` on ((`v`.`id_trans`
                                                                                                         =
                                                                                                         `t`.`id_trans`)))
  where 1
  group by 1
  order by 1 desc;

