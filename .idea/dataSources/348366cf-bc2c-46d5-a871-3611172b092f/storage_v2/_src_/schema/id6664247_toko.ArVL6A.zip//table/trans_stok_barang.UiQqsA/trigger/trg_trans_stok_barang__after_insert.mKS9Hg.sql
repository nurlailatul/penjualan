create trigger trg_trans_stok_barang__after_insert
  after INSERT
  on trans_stok_barang
  for each row
  BEGIN
    DECLARE v_stok INT;
    
    SELECT stok INTO v_stok
    FROM stok_barang
    WHERE id_barang = NEW.id_barang AND tgl <= NEW.created_date
    ORDER BY tgl DESC LIMIT 1;
    
    IF v_stok IS NULL THEN
       SET v_stok = 0;
    END IF;

    REPLACE INTO stok_barang (id_barang, tgl, stok)
    SELECT id_barang, created_date, v_stok + masuk - keluar
    FROM trans_stok_barang
    WHERE id_barang = NEW.id_barang AND created_date = NEW.created_date
    ORDER BY id_trans_stok DESC LIMIT 1;
END;

