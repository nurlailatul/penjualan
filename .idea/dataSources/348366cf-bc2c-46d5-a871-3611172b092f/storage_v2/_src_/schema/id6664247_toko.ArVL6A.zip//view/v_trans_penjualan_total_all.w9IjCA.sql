create view v_trans_penjualan_total_all as
  select `v_trans_penjualan_total`.`id_trans`                                                      AS `id_trans`,
         ((((`v_trans_penjualan_total`.`tot_harga_jual` + `v_trans_penjualan_total`.`biaya_tambahan`) +
            `v_trans_penjualan_total`.`biaya_pembatalan`) + coalesce(`v_trans_penjualan_total`.`biaya_pengiriman`, 0)) -
          `v_trans_penjualan_total`.`diskon`)                                                      AS `biaya_penjualan`,
         (`v_trans_penjualan_total`.`tot_harga_jual` - `v_trans_penjualan_total`.`tot_harga_beli`) AS `laba`
  from `id6664247_toko`.`v_trans_penjualan_total`;

