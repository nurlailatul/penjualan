create view v_trans_penjualan as
  select `v`.`id_trans`                AS `id_trans`,
         sum(`v`.`tot_harga_beli`)     AS `tot_harga_beli`,
         sum(`v`.`tot_harga_reseller`) AS `tot_harga_reseller`,
         sum(`v`.`tot_harga_umum`)     AS `tot_harga_umum`
  from `id6664247_toko`.`v_trans_penjualan_detail` `v`
  where 1
  group by 1
  order by 1 desc;

