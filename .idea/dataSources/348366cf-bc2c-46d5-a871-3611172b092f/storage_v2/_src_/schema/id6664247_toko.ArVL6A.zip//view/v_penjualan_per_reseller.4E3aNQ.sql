create view v_penjualan_per_reseller as
  select `t`.`id_reseller`          AS `id_reseller`,
         sum(`v`.`biaya_penjualan`) AS `tot_penjualan`,
         sum(`v`.`laba`)            AS `tot_laba`
  from (`id6664247_toko`.`v_trans_penjualan_total_all` `v` join `id6664247_toko`.`trans_penjualan` `t` on ((
    `v`.`id_trans` = `t`.`id_trans`)))
  where (`t`.`id_reseller` is not null)
  group by 1
  order by 1 desc;

