create view v_trans_pembelian_total as
  select `v_trans_pembelian`.`id_trans`                                                AS `id_trans`,
         (`v_trans_pembelian`.`tot_harga_beli` + `v_trans_pembelian`.`biaya_tambahan`) AS `biaya_pembelian`
  from `id6664247_toko`.`v_trans_pembelian`
  where 1
  order by 1 desc;

